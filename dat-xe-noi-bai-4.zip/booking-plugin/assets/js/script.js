jQuery(document).ready(function($) {
    
    // Biến lưu số điểm dừng
    let airportStopsCount = 0;
    let longStopsCount = 0;
    const MAX_STOPS = 2;
    
    // Khởi tạo
    initTabs();
    initAutocomplete();
    initEventListeners();
    
    // Xử lý tabs
    function initTabs() {
        $('.booking-tab-btn').on('click', function() {
            const tabName = $(this).data('tab');
            
            $('.booking-tab-btn').removeClass('active');
            $('.booking-tab-content').removeClass('active');
            
            $(this).addClass('active');
            $('#' + tabName + '-tab').addClass('active');
        });
    }
    
    // Khởi tạo Google Maps Autocomplete
    function initAutocomplete() {
        if (typeof google !== 'undefined' && google.maps) {
            const options = {
                componentRestrictions: { country: 'vn' }
            };
            
            const airportFrom = document.getElementById('airport-from');
            const longFrom = document.getElementById('long-from');
            const longTo = document.getElementById('long-to');
            
            if (airportFrom) new google.maps.places.Autocomplete(airportFrom, options);
            if (longFrom) new google.maps.places.Autocomplete(longFrom, options);
            if (longTo) new google.maps.places.Autocomplete(longTo, options);
        }
    }
    
    // Khởi tạo event listeners
    function initEventListeners() {
        // Nút đảo chiều sân bay
        $('#swap-airport').on('click', swapAirportLocations);
        
        // Nút thêm điểm dừng
        $('#add-airport-stop').on('click', function() {
            addStop('airport');
        });
        
        $('#add-long-stop').on('click', function() {
            addStop('long');
        });
        
        // Nút tính giá
        $('#calc-airport').on('click', function() {
            calculatePrice('airport');
        });
        
        $('#calc-long').on('click', function() {
            calculatePrice('long');
        });
        
        // Cập nhật hiển thị loại xe
        $('#airport-car-type').on('change', function() {
            updateCarDisplay('airport');
        });
        
        $('#long-car-type').on('change', function() {
            updateCarDisplay('long');
        });
        
        // Set thời gian mặc định
        setDefaultDateTime();
        
        // Xử lý submit đặt xe
        $('#submit-airport').on('click', function(e) {
            e.preventDefault();
            submitBooking('airport');
        });
        
        $('#submit-long').on('click', function(e) {
            e.preventDefault();
            submitBooking('long');
        });
    }
    
    // Submit đặt xe
    function submitBooking(type) {
        const phone = $('#' + type + '-phone').val();
        const name = $('#' + type + '-name').val();
        
        if (!phone || !name) {
            alert('Vui lòng nhập đầy đủ thông tin liên hệ');
            return;
        }
        
        // Validate số điện thoại
        const phoneRegex = /^[0-9]{10,11}$/;
        if (!phoneRegex.test(phone)) {
            alert('Số điện thoại không hợp lệ');
            return;
        }
        
        const $btn = $('#submit-' + type);
        $btn.prop('disabled', true).html('Đang xử lý... <span class="booking-loading"></span>');
        
        // Gọi AJAX để lưu booking
        $.ajax({
            url: bookingAjax.ajaxurl,
            type: 'POST',
            data: {
                action: 'submit_booking',
                nonce: bookingAjax.nonce,
                type: type,
                phone: phone,
                name: name,
                from: $('#' + type + '-from').val(),
                to: $('#' + type + '-to').val(),
                car_type: $('#' + type + '-car-type').val(),
                datetime: $('#' + type + '-datetime').val(),
                price: $('#' + type + '-price').text()
            },
            success: function(response) {
                if (response.success) {
                    alert('Đặt xe thành công! Chúng tôi sẽ liên hệ với bạn sớm nhất.');
                    location.reload();
                } else {
                    alert(response.data.message || 'Có lỗi xảy ra. Vui lòng thử lại.');
                }
            },
            error: function() {
                alert('Có lỗi xảy ra. Vui lòng thử lại.');
            },
            complete: function() {
                $btn.prop('disabled', false).html('Đặt xe <span>→</span>');
            }
        });
    }
    
    // Thêm điểm dừng
    function addStop(type) {
        const stopsCount = type === 'airport' ? airportStopsCount : longStopsCount;
        
        if (stopsCount >= MAX_STOPS) {
            alert('Chỉ được thêm tối đa ' + MAX_STOPS + ' điểm dừng');
            return;
        }
        
        const stopId = type + '-stop-' + (stopsCount + 1);
        const stopHtml = `
            <div class="booking-form-group booking-stop-item" id="${stopId}">
                <label>Điểm dừng ${stopsCount + 1}:</label>
                <div class="booking-input-wrapper">
                    <span class="booking-location-icon">🟢</span>
                    <input type="text" class="booking-location-input ${type}-stop-input" placeholder="Điểm dừng tiếp theo">
                    <button class="booking-remove-stop-btn" onclick="removeStop('${stopId}', '${type}')">−</button>
                </div>
            </div>
        `;
        
        $('#' + type + '-stops-container').append(stopHtml);
        
        // Khởi tạo autocomplete cho input mới
        const newInput = $('#' + stopId + ' input')[0];
        if (typeof google !== 'undefined' && google.maps) {
            new google.maps.places.Autocomplete(newInput, {
                componentRestrictions: { country: 'vn' }
            });
        }
        
        if (type === 'airport') {
            airportStopsCount++;
        } else {
            longStopsCount++;
        }
        
        // Ẩn nút thêm nếu đã đủ
        if ((type === 'airport' ? airportStopsCount : longStopsCount) >= MAX_STOPS) {
            $('#add-' + type + '-stop').hide();
        }
    }
    
    // Xóa điểm dừng (global function)
    window.removeStop = function(stopId, type) {
        $('#' + stopId).remove();
        
        if (type === 'airport') {
            airportStopsCount--;
        } else {
            longStopsCount--;
        }
        
        // Hiện lại nút thêm
        $('#add-' + type + '-stop').show();
        
        // Cập nhật lại số thứ tự
        $('#' + type + '-stops-container .booking-stop-item').each(function(index) {
            $(this).find('label').text('Điểm dừng ' + (index + 1) + ':');
        });
    };
    
    // Set thời gian mặc định (hiện tại + 1 giờ)
    function setDefaultDateTime() {
        const now = new Date();
        now.setHours(now.getHours() + 1);
        const dateTimeString = now.toISOString().slice(0, 16);
        $('#airport-datetime').val(dateTimeString);
        $('#long-datetime').val(dateTimeString);
    }
    
    // Cập nhật hiển thị loại xe
    function updateCarDisplay(type) {
        const carType = $('#' + type + '-car-type').val();
        const carNames = {
            '4-seat': '4 chỗ cốp rộng',
            '7-seat': '7 chỗ',
            '4-seat-small': '4 chỗ cốp nhỏ',
            '16-seat': '16 chỗ',
            '29-seat': '29 chỗ',
            '45-seat': '45 chỗ'
        };
        $('#' + type + '-car-display').text(carNames[carType]);
    }
    
    // Đảo chiều điểm đi - điểm đến (Sân bay)
    function swapAirportLocations() {
        const $fromInput = $('#airport-from');
        const $toInput = $('#airport-to');
        
        const tempValue = $fromInput.val();
        $fromInput.val($toInput.val());
        $toInput.val(tempValue);
        
        // Toggle readonly
        if ($fromInput.prop('readonly')) {
            $fromInput.prop('readonly', false);
            $toInput.prop('readonly', true);
            $toInput.val('Sân bay Nội Bài');
        } else {
            $fromInput.prop('readonly', true);
            $toInput.prop('readonly', false);
            $fromInput.val('Sân bay Nội Bài');
        }
    }
    
    // Tính giá
    function calculatePrice(type) {
        let from, to, roundTrip, needVAT, carType, datetime;
        
        if (type === 'airport') {
            from = $('#airport-from').val();
            to = $('#airport-to').val();
            roundTrip = $('#round-trip').is(':checked');
            needVAT = $('#vat-airport').is(':checked');
            carType = $('#airport-car-type').val();
            datetime = $('#airport-datetime').val();
        } else {
            from = $('#long-from').val();
            to = $('#long-to').val();
            roundTrip = false;
            needVAT = $('#vat-long').is(':checked');
            carType = $('#long-car-type').val();
            datetime = $('#long-datetime').val();
        }
        
        if (!from || !to) {
            alert('Vui lòng nhập đầy đủ thông tin điểm đi và điểm đến');
            return;
        }
        
        if (!datetime) {
            alert('Vui lòng chọn thời gian đi');
            return;
        }
        
        const $btn = $('#calc-' + type);
        $btn.prop('disabled', true).html('Đang tính... <span class="booking-loading"></span>');
        
        // Gọi AJAX để tính khoảng cách
        $.ajax({
            url: bookingAjax.ajaxurl,
            type: 'POST',
            data: {
                action: 'calculate_distance',
                nonce: bookingAjax.nonce,
                origin: from,
                destination: to,
                car_type: carType,
                datetime: datetime
            },
            success: function(response) {
                if (response.success) {
                    const distance = response.data.distance;
                    const pricing = type === 'airport' ? bookingAjax.pricing.airport : bookingAjax.pricing.longDistance;
                    
                    // Tính giá cơ bản theo loại xe
                    let basePrice = pricing.basePrice;
                    const carMultipliers = {
                        '4-seat': 1,
                        '7-seat': 1.3,
                        '4-seat-small': 0.9,
                        '16-seat': 2,
                        '29-seat': 3,
                        '45-seat': 4
                    };
                    
                    let price = distance * basePrice * carMultipliers[carType];
                    
                    if (roundTrip && type === 'airport') {
                        price = price * 2 * pricing.roundTripMultiplier;
                    }
                    
                    if (needVAT) {
                        price = price * (1 + pricing.vatRate);
                    }
                    
                    displayResult(type, distance, price, roundTrip);
                    
                    // Hiện form liên hệ
                    $('#' + type + '-result-box').slideDown(400);
                    $('#' + type + '-contact-form').slideDown(400);
                    $('#calc-' + type).hide();
                } else {
                    alert(response.data.message || 'Không thể tính khoảng cách');
                }
            },
            error: function() {
                alert('Có lỗi xảy ra. Vui lòng thử lại.');
            },
            complete: function() {
                $btn.prop('disabled', false).text('Kiểm Tra Giá');
            }
        });
    }
    
    // Hiển thị kết quả
    function displayResult(type, distance, price, isRoundTrip) {
        let displayDistance = distance;
        if (isRoundTrip) {
            displayDistance = distance * 2;
        }
        
        $('#' + type + '-price').text(formatPrice(price));
    }
    
    // Format giá tiền
    function formatPrice(price) {
        return new Intl.NumberFormat('vi-VN', {
            style: 'currency',
            currency: 'VND'
        }).format(price);
    }
});
