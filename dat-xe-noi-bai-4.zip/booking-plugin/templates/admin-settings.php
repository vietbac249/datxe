<div class="wrap">
    <h1>Cài Đặt Plugin Đặt Xe</h1>
    
    <form method="post" action="options.php">
        <?php settings_fields('booking_plugin_settings'); ?>
        <?php do_settings_sections('booking_plugin_settings'); ?>
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="booking_google_api_key">Google Maps API Key</label>
                </th>
                <td>
                    <input type="text" 
                           id="booking_google_api_key" 
                           name="booking_google_api_key" 
                           value="<?php echo esc_attr(get_option('booking_google_api_key', '')); ?>" 
                           class="regular-text">
                    <p class="description">
                        Nhập Google Maps API Key. 
                        <a href="https://console.cloud.google.com/" target="_blank">Lấy API Key tại đây</a>
                    </p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="booking_airport_price">Giá Sân Bay (VNĐ/km)</label>
                </th>
                <td>
                    <input type="number" 
                           id="booking_airport_price" 
                           name="booking_airport_price" 
                           value="<?php echo esc_attr(get_option('booking_airport_price', 15000)); ?>" 
                           class="regular-text">
                    <p class="description">Giá mỗi km cho chuyến đi sân bay</p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="booking_long_price">Giá Đường Dài (VNĐ/km)</label>
                </th>
                <td>
                    <input type="number" 
                           id="booking_long_price" 
                           name="booking_long_price" 
                           value="<?php echo esc_attr(get_option('booking_long_price', 12000)); ?>" 
                           class="regular-text">
                    <p class="description">Giá mỗi km cho chuyến đi đường dài</p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="booking_roundtrip_multiplier">Hệ Số Đi 2 Chiều</label>
                </th>
                <td>
                    <input type="number" 
                           id="booking_roundtrip_multiplier" 
                           name="booking_roundtrip_multiplier" 
                           value="<?php echo esc_attr(get_option('booking_roundtrip_multiplier', 1.8)); ?>" 
                           step="0.1"
                           class="regular-text">
                    <p class="description">Hệ số nhân cho chuyến đi 2 chiều (1.8 = giảm 10%)</p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="booking_vat_rate">Thuế VAT (%)</label>
                </th>
                <td>
                    <input type="number" 
                           id="booking_vat_rate" 
                           name="booking_vat_rate" 
                           value="<?php echo esc_attr(get_option('booking_vat_rate', 0.1)); ?>" 
                           step="0.01"
                           class="regular-text">
                    <p class="description">Tỷ lệ VAT (0.1 = 10%)</p>
                </td>
            </tr>
        </table>
        
        <h3>Hệ Số Giá Theo Loại Xe</h3>
        <table class="form-table">
            <tr>
                <td>
                    <p><strong>4 chỗ cốp rộng:</strong> x1.0 (giá gốc)</p>
                    <p><strong>7 chỗ:</strong> x1.3</p>
                    <p><strong>4 chỗ cốp nhỏ:</strong> x0.9</p>
                    <p><strong>16 chỗ:</strong> x2.0</p>
                    <p><strong>29 chỗ:</strong> x3.0</p>
                    <p><strong>45 chỗ:</strong> x4.0</p>
                    <p class="description">Hệ số này được nhân với giá cơ bản để tính giá cuối cùng</p>
                </td>
            </tr>
        </table>
        
        <?php submit_button('Lưu Cài Đặt'); ?>
    </form>
    
    <hr>
    
    <h2>Hướng Dẫn Sử Dụng</h2>
    <p>Để hiển thị form đặt xe trên trang hoặc bài viết, sử dụng shortcode:</p>
    <code>[dat_xe]</code>
    
    <h3>Các bước cài đặt:</h3>
    <ol>
        <li>Lấy Google Maps API Key từ <a href="https://console.cloud.google.com/" target="_blank">Google Cloud Console</a></li>
        <li>Bật các API sau: Maps JavaScript API, Places API, Distance Matrix API</li>
        <li>Nhập API Key vào ô bên trên</li>
        <li>Cấu hình giá cước theo nhu cầu</li>
        <li>Thêm shortcode <code>[dat_xe]</code> vào trang/bài viết</li>
    </ol>
</div>

<style>
.wrap {
    max-width: 900px;
}
.wrap code {
    background: #f0f0f0;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 14px;
}
</style>
