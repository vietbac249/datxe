<div class="booking-container">
    <h2 class="booking-title">ĐẶT XE</h2>
    
    <!-- Tabs -->
    <div class="booking-tabs">
        <button class="booking-tab-btn active" data-tab="airport">Sân bay</button>
        <button class="booking-tab-btn" data-tab="longdistance">Đường dài</button>
    </div>

    <!-- Tab 1: Sân bay Nội Bài -->
    <div class="booking-tab-content active" id="airport-tab">
        <div class="booking-form-group">
            <label>Bạn đi từ:</label>
            <div class="booking-input-wrapper">
                <span class="booking-location-icon origin">⊙</span>
                <input type="text" id="airport-from" class="booking-location-input" placeholder="Điểm đi">
                <button class="booking-add-stop-btn" id="add-airport-stop" title="Thêm điểm dừng">+</button>
            </div>
        </div>

        <div id="airport-stops-container"></div>

        <div class="booking-form-group">
            <label>Bạn muốn đến:</label>
            <div class="booking-input-wrapper">
                <span class="booking-location-icon destination">📍</span>
                <input type="text" id="airport-to" class="booking-location-input" value="Sân bay Nội Bài" readonly>
            </div>
        </div>

        <div class="booking-toggles-row">
            <div class="booking-toggle-group">
                <label class="booking-toggle-switch">
                    <input type="checkbox" id="round-trip">
                    <span class="booking-toggle-slider"></span>
                </label>
                <label for="round-trip">2 chiều</label>
            </div>

            <div class="booking-toggle-group">
                <label class="booking-toggle-switch">
                    <input type="checkbox" id="vat-airport">
                    <span class="booking-toggle-slider"></span>
                </label>
                <label for="vat-airport">VAT</label>
            </div>

            <button class="booking-swap-btn" id="swap-airport">
                🔄 Đảo chiều
            </button>
        </div>

        <div class="booking-form-row">
            <div class="booking-form-group">
                <label>Loại xe</label>
                <div class="booking-select-wrapper">
                    <span class="booking-select-icon">🚗</span>
                    <select id="airport-car-type" class="booking-select">
                        <option value="4-seat">4 chỗ cốp rộng</option>
                        <option value="7-seat">7 chỗ</option>
                        <option value="4-seat-small">4 chỗ cốp nhỏ</option>
                        <option value="16-seat">16 chỗ</option>
                        <option value="29-seat">29 chỗ</option>
                        <option value="45-seat">45 chỗ</option>
                    </select>
                </div>
            </div>

            <div class="booking-form-group">
                <label>Thời gian đi</label>
                <div class="booking-datetime-wrapper">
                    <span class="booking-datetime-icon">📅</span>
                    <input type="datetime-local" id="airport-datetime" class="booking-datetime" placeholder="Thời gian đi">
                </div>
            </div>
        </div>

        <div class="booking-divider"></div>

        <div class="booking-result-box" id="airport-result-box" style="display: none;">
            <div class="booking-result-item">
                <span>💵 Cước phí đi</span>
                <strong id="airport-price" style="color: #5b3a9d; font-size: 20px;">-- VNĐ</strong>
            </div>
        </div>

        <div class="booking-contact-form" id="airport-contact-form" style="display: none;">
            <h3 class="booking-contact-title">Thông tin của bạn</h3>
            
            <div class="booking-form-row">
                <div class="booking-form-group">
                    <div class="booking-input-wrapper">
                        <span class="booking-location-icon">📞</span>
                        <input type="tel" id="airport-phone" class="booking-location-input" placeholder="Số điện thoại" required>
                    </div>
                </div>

                <div class="booking-form-group">
                    <div class="booking-input-wrapper">
                        <span class="booking-location-icon">👤</span>
                        <input type="text" id="airport-name" class="booking-location-input" placeholder="Họ và tên" required>
                    </div>
                </div>
            </div>

            <div class="booking-extra-options">
                <a href="#" class="booking-extra-link">+ Thêm ghi chú</a>
                <a href="#" class="booking-extra-link">+ Mã giảm giá</a>
            </div>

            <button class="booking-btn-submit" id="submit-airport">
                Đặt xe
                <span>→</span>
            </button>
        </div>

        <button class="booking-btn-calculate" id="calc-airport">
            Kiểm Tra Giá
            <span>→</span>
        </button>
    </div>

    <!-- Tab 2: Đường dài -->
    <div class="booking-tab-content" id="longdistance-tab">
        <div class="booking-form-group">
            <label>Điểm đi:</label>
            <div class="booking-input-wrapper">
                <span class="booking-location-icon origin">⊙</span>
                <input type="text" id="long-from" class="booking-location-input" placeholder="Điểm đi">
                <button class="booking-add-stop-btn" id="add-long-stop" title="Thêm điểm dừng">+</button>
            </div>
        </div>

        <div id="long-stops-container"></div>

        <div class="booking-form-group">
            <label>Điểm đến:</label>
            <div class="booking-input-wrapper">
                <span class="booking-location-icon destination">📍</span>
                <input type="text" id="long-to" class="booking-location-input" placeholder="Điểm đến">
            </div>
        </div>

        <div class="booking-toggles-row">
            <div class="booking-toggle-group">
                <label class="booking-toggle-switch">
                    <input type="checkbox" id="vat-long">
                    <span class="booking-toggle-slider"></span>
                </label>
                <label for="vat-long">VAT</label>
            </div>
        </div>

        <div class="booking-form-row">
            <div class="booking-form-group">
                <label>Loại xe</label>
                <div class="booking-select-wrapper">
                    <span class="booking-select-icon">🚗</span>
                    <select id="long-car-type" class="booking-select">
                        <option value="4-seat">4 chỗ cốp rộng</option>
                        <option value="7-seat">7 chỗ</option>
                        <option value="4-seat-small">4 chỗ cốp nhỏ</option>
                        <option value="16-seat">16 chỗ</option>
                        <option value="29-seat">29 chỗ</option>
                        <option value="45-seat">45 chỗ</option>
                    </select>
                </div>
            </div>

            <div class="booking-form-group">
                <label>Thời gian đi</label>
                <div class="booking-datetime-wrapper">
                    <span class="booking-datetime-icon">📅</span>
                    <input type="datetime-local" id="long-datetime" class="booking-datetime" placeholder="Thời gian đi">
                </div>
            </div>
        </div>

        <div class="booking-divider"></div>

        <div class="booking-result-box" id="long-result-box" style="display: none;">
            <div class="booking-result-item">
                <span>💵 Cước phí đi</span>
                <strong id="long-price" style="color: #5b3a9d; font-size: 20px;">-- VNĐ</strong>
            </div>
        </div>

        <div class="booking-contact-form" id="long-contact-form" style="display: none;">
            <h3 class="booking-contact-title">Thông tin của bạn</h3>
            
            <div class="booking-form-row">
                <div class="booking-form-group">
                    <div class="booking-input-wrapper">
                        <span class="booking-location-icon">📞</span>
                        <input type="tel" id="long-phone" class="booking-location-input" placeholder="Số điện thoại" required>
                    </div>
                </div>

                <div class="booking-form-group">
                    <div class="booking-input-wrapper">
                        <span class="booking-location-icon">👤</span>
                        <input type="text" id="long-name" class="booking-location-input" placeholder="Họ và tên" required>
                    </div>
                </div>
            </div>

            <div class="booking-extra-options">
                <a href="#" class="booking-extra-link">+ Thêm ghi chú</a>
                <a href="#" class="booking-extra-link">+ Mã giảm giá</a>
            </div>

            <button class="booking-btn-submit" id="submit-long">
                Đặt xe
                <span>→</span>
            </button>
        </div>

        <button class="booking-btn-calculate" id="calc-long">
            Kiểm Tra Giá
            <span>→</span>
        </button>
    </div>
</div>
